# Overview

This is a Pakistani wedding hall website built as a full-stack application. The project provides a professional online presence for "Shaadi Palace," a wedding venue that specializes in Pakistani wedding ceremonies including Mehndi, Nikah, and Walima celebrations. The website features a modern design with Pakistani cultural elements, allowing visitors to view services, browse a photo gallery, and submit contact inquiries through a form.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

The frontend is built using **React with TypeScript** and follows a component-based architecture:

- **UI Framework**: Uses shadcn/ui components with Radix UI primitives for consistent, accessible design
- **Styling**: Tailwind CSS with custom Pakistani-themed color variables (Pakistani green #006A4E and gold #FFD700)
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React Query (@tanstack/react-query) for server state management
- **Form Handling**: React Hook Form with Zod validation for type-safe form processing
- **Build Tool**: Vite for fast development and optimized production builds

The application is structured as a single-page application with modular components for each section (Header, Hero, About, Gallery, Services, Contact, Footer).

## Backend Architecture

The backend uses **Express.js with TypeScript** in an ESM module setup:

- **Server Framework**: Express.js with middleware for JSON parsing and request logging
- **Data Storage**: In-memory storage implementation (MemStorage) that can be easily swapped for database persistence
- **API Design**: RESTful endpoints for contact form submissions (`POST /api/contact`) and inquiry retrieval (`GET /api/contact`)
- **Validation**: Zod schemas shared between frontend and backend for consistent data validation
- **Development**: Custom Vite integration for hot module replacement in development

## Data Storage Solutions

Currently implements **in-memory storage** with a well-defined interface (IStorage) that supports:

- User management (prepared for authentication features)
- Contact inquiry storage and retrieval
- Easy migration path to PostgreSQL through Drizzle ORM configuration

The database schema is defined using **Drizzle ORM** with PostgreSQL dialect, including:
- Users table with username/password authentication
- Contact inquiries table with wedding-specific fields (date, guest count, ceremony preferences)

## External Dependencies

- **Neon Database**: Serverless PostgreSQL database (@neondatabase/serverless) configured for production use
- **UI Components**: Comprehensive shadcn/ui component library built on Radix UI primitives
- **Unsplash Images**: External image hosting for Pakistani wedding photography in the gallery
- **Google Fonts**: Inter and Playfair Display fonts for modern typography
- **Font Awesome**: Icon library for UI elements

The architecture supports easy scaling from the current in-memory storage to full database persistence while maintaining the same API interface and user experience.