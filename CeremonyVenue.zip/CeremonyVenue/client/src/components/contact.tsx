import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertContactInquirySchema } from "@shared/schema";
import type { InsertContactInquiry } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Phone, Mail, MapPin } from "lucide-react";

export default function Contact() {
  const { toast } = useToast();
  const [showSuccess, setShowSuccess] = useState(false);

  const form = useForm<InsertContactInquiry>({
    resolver: zodResolver(insertContactInquirySchema),
    defaultValues: {
      name: "",
      phone: "",
      email: "",
      weddingDate: "",
      guests: "",
      message: ""
    }
  });

  const contactMutation = useMutation({
    mutationFn: async (data: InsertContactInquiry) => {
      const response = await apiRequest("POST", "/api/contact", data);
      return response.json();
    },
    onSuccess: () => {
      setShowSuccess(true);
      form.reset();
      toast({
        title: "Success!",
        description: "Your inquiry has been sent successfully. We'll contact you soon.",
      });
      
      // Hide success message after 5 seconds
      setTimeout(() => {
        setShowSuccess(false);
      }, 5000);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to send inquiry. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertContactInquiry) => {
    contactMutation.mutate(data);
  };

  return (
    <section id="contact" className="py-20" data-testid="section-contact">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-primary section-title mb-6" data-testid="text-contact-title">
            Contact Us
          </h2>
          <p className="text-xl text-muted-foreground" data-testid="text-contact-subtitle">
            Get in touch to book your special day
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Information */}
          <div className="space-y-8">
            <div className="flex items-start space-x-4" data-testid="contact-info-phone">
              <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center flex-shrink-0">
                <Phone className="text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-primary mb-2" data-testid="text-phone-title">
                  Phone & WhatsApp
                </h3>
                <p className="text-muted-foreground" data-testid="text-phone-number">+92-XXX-XXXXXXX</p>
                <p className="text-muted-foreground" data-testid="text-whatsapp-number">+92-XXX-XXXXXXX (WhatsApp)</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4" data-testid="contact-info-email">
              <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center flex-shrink-0">
                <Mail className="text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-primary mb-2" data-testid="text-email-title">
                  Email
                </h3>
                <p className="text-muted-foreground" data-testid="text-email-address">info@shaadipalace.com</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4" data-testid="contact-info-address">
              <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center flex-shrink-0">
                <MapPin className="text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-primary mb-2" data-testid="text-address-title">
                  Address
                </h3>
                <p className="text-muted-foreground" data-testid="text-address-details">
                  123 Wedding Street, Gulberg<br />Lahore, Punjab, Pakistan
                </p>
              </div>
            </div>
          </div>
          
          {/* Contact Form */}
          <div className="bg-card p-8 rounded-xl shadow-lg">
            {showSuccess ? (
              <div className="p-6 bg-primary/10 border border-primary/20 rounded-lg text-center" data-testid="success-message">
                <p className="text-primary font-medium">
                  Thank you! Your inquiry has been sent successfully. We'll contact you soon.
                </p>
              </div>
            ) : (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6" data-testid="contact-form">
                  <div className="grid md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel data-testid="label-name">Full Name</FormLabel>
                          <FormControl>
                            <Input {...field} data-testid="input-name" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel data-testid="label-phone">Phone Number</FormLabel>
                          <FormControl>
                            <Input {...field} type="tel" data-testid="input-phone" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel data-testid="label-email">Email Address</FormLabel>
                        <FormControl>
                          <Input {...field} type="email" data-testid="input-email" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="weddingDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel data-testid="label-wedding-date">Wedding Date</FormLabel>
                          <FormControl>
                            <Input {...field} type="date" data-testid="input-wedding-date" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="guests"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel data-testid="label-guests">Number of Guests</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-guests">
                                <SelectValue placeholder="Select Range" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="50-100" data-testid="option-guests-50-100">50-100 Guests</SelectItem>
                              <SelectItem value="100-200" data-testid="option-guests-100-200">100-200 Guests</SelectItem>
                              <SelectItem value="200-300" data-testid="option-guests-200-300">200-300 Guests</SelectItem>
                              <SelectItem value="300-500" data-testid="option-guests-300-500">300-500 Guests</SelectItem>
                              <SelectItem value="500+" data-testid="option-guests-500-plus">500+ Guests</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel data-testid="label-message">Message</FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            value={field.value || ''}
                            rows={4}
                            placeholder="Tell us about your wedding requirements..."
                            data-testid="textarea-message"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button
                    type="submit"
                    className="w-full bg-primary hover:bg-primary/90"
                    disabled={contactMutation.isPending}
                    data-testid="button-submit-inquiry"
                  >
                    {contactMutation.isPending ? "Sending..." : "Send Inquiry"}
                  </Button>
                </form>
              </Form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
