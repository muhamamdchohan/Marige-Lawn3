import { useState } from "react";
import { Crown, Menu } from "lucide-react";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleNavClick = (href: string) => {
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <header className="fixed top-0 w-full bg-white/95 backdrop-blur-sm shadow-sm z-50" data-testid="header-main">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Crown className="text-secondary text-2xl" />
            <h1 className="text-2xl font-bold text-primary hero-text" data-testid="text-brand-name">Shaadi Palace</h1>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8" data-testid="nav-desktop">
            <button
              onClick={() => handleNavClick('#home')}
              className="text-foreground hover:text-primary transition-colors"
              data-testid="link-home"
            >
              Home
            </button>
            <button
              onClick={() => handleNavClick('#about')}
              className="text-foreground hover:text-primary transition-colors"
              data-testid="link-about"
            >
              About
            </button>
            <button
              onClick={() => handleNavClick('#gallery')}
              className="text-foreground hover:text-primary transition-colors"
              data-testid="link-gallery"
            >
              Gallery
            </button>
            <button
              onClick={() => handleNavClick('#services')}
              className="text-foreground hover:text-primary transition-colors"
              data-testid="link-services"
            >
              Services
            </button>
            <button
              onClick={() => handleNavClick('#contact')}
              className="text-foreground hover:text-primary transition-colors"
              data-testid="link-contact"
            >
              Contact
            </button>
          </nav>
          
          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden text-primary"
            data-testid="button-mobile-menu"
          >
            <Menu className="text-2xl" />
          </button>
        </div>
        
        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 border-t border-border animate-slideDown" data-testid="nav-mobile">
            <div className="flex flex-col space-y-3 pt-4">
              <button
                onClick={() => handleNavClick('#home')}
                className="text-left text-foreground hover:text-primary transition-colors"
                data-testid="link-mobile-home"
              >
                Home
              </button>
              <button
                onClick={() => handleNavClick('#about')}
                className="text-left text-foreground hover:text-primary transition-colors"
                data-testid="link-mobile-about"
              >
                About
              </button>
              <button
                onClick={() => handleNavClick('#gallery')}
                className="text-left text-foreground hover:text-primary transition-colors"
                data-testid="link-mobile-gallery"
              >
                Gallery
              </button>
              <button
                onClick={() => handleNavClick('#services')}
                className="text-left text-foreground hover:text-primary transition-colors"
                data-testid="link-mobile-services"
              >
                Services
              </button>
              <button
                onClick={() => handleNavClick('#contact')}
                className="text-left text-foreground hover:text-primary transition-colors"
                data-testid="link-mobile-contact"
              >
                Contact
              </button>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}
