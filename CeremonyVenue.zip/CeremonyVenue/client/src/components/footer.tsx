import { Crown } from "lucide-react";

export default function Footer() {
  const handleNavClick = (href: string) => {
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <footer className="bg-primary text-white py-12" data-testid="footer-main">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Crown className="text-secondary text-2xl" />
              <h3 className="text-2xl font-bold hero-text" data-testid="text-footer-brand">Shaadi Palace</h3>
            </div>
            <p className="text-primary-foreground/80" data-testid="text-footer-description">
              Creating unforgettable Pakistani wedding experiences since 2010.
            </p>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4" data-testid="text-quick-links-title">Quick Links</h4>
            <div className="space-y-2">
              <button
                onClick={() => handleNavClick('#home')}
                className="block text-primary-foreground/80 hover:text-white transition-colors text-left"
                data-testid="link-footer-home"
              >
                Home
              </button>
              <button
                onClick={() => handleNavClick('#about')}
                className="block text-primary-foreground/80 hover:text-white transition-colors text-left"
                data-testid="link-footer-about"
              >
                About
              </button>
              <button
                onClick={() => handleNavClick('#gallery')}
                className="block text-primary-foreground/80 hover:text-white transition-colors text-left"
                data-testid="link-footer-gallery"
              >
                Gallery
              </button>
              <button
                onClick={() => handleNavClick('#services')}
                className="block text-primary-foreground/80 hover:text-white transition-colors text-left"
                data-testid="link-footer-services"
              >
                Services
              </button>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4" data-testid="text-follow-us-title">Follow Us</h4>
            <div className="flex space-x-4">
              <a
                href="#"
                className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center text-secondary-foreground hover:bg-secondary/90 transition-colors"
                data-testid="link-facebook"
              >
                <i className="fab fa-facebook-f"></i>
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center text-secondary-foreground hover:bg-secondary/90 transition-colors"
                data-testid="link-instagram"
              >
                <i className="fab fa-instagram"></i>
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center text-secondary-foreground hover:bg-secondary/90 transition-colors"
                data-testid="link-whatsapp"
              >
                <i className="fab fa-whatsapp"></i>
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-primary-foreground/20 mt-8 pt-8 text-center">
          <p className="text-primary-foreground/80" data-testid="text-copyright">
            &copy; 2024 Shaadi Palace. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
