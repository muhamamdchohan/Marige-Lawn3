import { 
  UtensilsCrossed, 
  Palette, 
  Building2, 
  Sparkles, 
  Music, 
  Camera, 
  Car, 
  Heart 
} from "lucide-react";

const services = [
  {
    icon: UtensilsCrossed,
    title: "Pakistani Catering",
    description: "Biryani, Karahi, Traditional Sweets"
  },
  {
    icon: Palette,
    title: "Mehndi Decorations",
    description: "Colorful traditional ceremony setup"
  },
  {
    icon: Building2,
    title: "Nikah Setup",
    description: "Elegant Islamic ceremony arrangements"
  },
  {
    icon: Sparkles,
    title: "Walima Planning",
    description: "Grand reception celebrations"
  },
  {
    icon: Music,
    title: "Cultural Music",
    description: "Traditional Pakistani wedding music"
  },
  {
    icon: Camera,
    title: "Photography",
    description: "Professional wedding photography"
  },
  {
    icon: Car,
    title: "Parking",
    description: "Ample parking facilities available"
  },
  {
    icon: Heart,
    title: "Prayer Area",
    description: "Dedicated prayer space available"
  }
];

export default function Services() {
  return (
    <section id="services" className="py-20 bg-muted" data-testid="section-services">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-primary section-title mb-6" data-testid="text-services-title">
            Our Services
          </h2>
          <p className="text-xl text-muted-foreground" data-testid="text-services-subtitle">
            Complete Pakistani wedding services for your special day
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <div
                key={index}
                className="bg-card p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow"
                data-testid={`service-card-${index}`}
              >
                <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center mb-4">
                  <IconComponent className="text-secondary-foreground" />
                </div>
                <h3 className="text-xl font-bold text-primary mb-3" data-testid={`text-service-title-${index}`}>
                  {service.title}
                </h3>
                <p className="text-muted-foreground text-sm" data-testid={`text-service-description-${index}`}>
                  {service.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
