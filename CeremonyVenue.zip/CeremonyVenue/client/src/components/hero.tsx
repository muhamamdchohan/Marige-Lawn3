export default function Hero() {
  const handleNavClick = (href: string) => {
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden" data-testid="section-hero">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1583931433200-0bb4339015c3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')`
        }}
      />
      <div className="absolute inset-0 bg-black/40"></div>
      
      <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
        <h1 className="text-5xl md:text-7xl font-bold hero-text mb-6 animate-fadeIn" data-testid="text-hero-title">
          Your Dream Pakistani Wedding
        </h1>
        <p className="text-xl md:text-2xl mb-8 animate-fadeIn" data-testid="text-hero-subtitle">
          Creating unforgettable moments for Mehndi, Nikah & Walima celebrations
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fadeIn">
          <button
            onClick={() => handleNavClick('#contact')}
            className="bg-primary hover:bg-primary/90 text-white px-8 py-4 rounded-lg font-semibold transition-colors"
            data-testid="button-book-event"
          >
            Book Your Event
          </button>
          <button
            onClick={() => handleNavClick('#gallery')}
            className="border-2 border-white text-white hover:bg-white hover:text-primary px-8 py-4 rounded-lg font-semibold transition-colors"
            data-testid="button-view-gallery"
          >
            View Gallery
          </button>
        </div>
      </div>
    </section>
  );
}
