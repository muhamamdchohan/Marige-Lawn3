import { Building2, Heart, Sparkles } from "lucide-react";

export default function About() {
  return (
    <section id="about" className="py-20 bg-muted" data-testid="section-about">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-primary section-title mb-6" data-testid="text-about-title">
              About Shaadi Palace
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-about-description">
              We provide the perfect venue for your special Pakistani wedding celebrations. Our hall accommodates Mehndi, Nikah, and Walima ceremonies with traditional Pakistani decorations and halal catering services.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-card p-8 rounded-xl shadow-lg text-center hover:shadow-xl transition-shadow" data-testid="card-mehndi">
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-6">
                <Sparkles className="text-2xl text-secondary-foreground" />
              </div>
              <h3 className="text-2xl font-bold text-primary mb-4 section-title" data-testid="text-mehndi-title">
                Mehndi Ceremonies
              </h3>
              <p className="text-muted-foreground" data-testid="text-mehndi-description">
                Vibrant and colorful Mehndi celebrations with traditional Pakistani decorations and music
              </p>
            </div>
            
            <div className="bg-card p-8 rounded-xl shadow-lg text-center hover:shadow-xl transition-shadow" data-testid="card-nikah">
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-6">
                <Heart className="text-2xl text-secondary-foreground" />
              </div>
              <h3 className="text-2xl font-bold text-primary mb-4 section-title" data-testid="text-nikah-title">
                Nikah Ceremonies
              </h3>
              <p className="text-muted-foreground" data-testid="text-nikah-description">
                Elegant and formal Islamic wedding ceremonies with proper prayer arrangements
              </p>
            </div>
            
            <div className="bg-card p-8 rounded-xl shadow-lg text-center hover:shadow-xl transition-shadow" data-testid="card-walima">
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-6">
                <Building2 className="text-2xl text-secondary-foreground" />
              </div>
              <h3 className="text-2xl font-bold text-primary mb-4 section-title" data-testid="text-walima-title">
                Walima Receptions
              </h3>
              <p className="text-muted-foreground" data-testid="text-walima-description">
                Grand Pakistani celebration receptions with traditional cuisine and entertainment
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
